<?php

const bar = 'global bar';
