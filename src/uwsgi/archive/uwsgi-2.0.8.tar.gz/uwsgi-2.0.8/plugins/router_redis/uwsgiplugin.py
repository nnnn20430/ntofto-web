NAME='router_redis'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['router_redis']
