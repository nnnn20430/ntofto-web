package #
Locale::Codes::LangExt_Retired;

# This file was automatically generated.  Any changes to this file will
# be lost the next time 'deprecate_codes' is run.
#    Generated on: Tue Mar  4 13:19:40 EST 2014

use strict;
require 5.006;
use warnings;
use utf8;

our($VERSION);
$VERSION='3.30';

$Locale::Codes::Retired{'langext'}{'alpha'}{'code'} = {
};

$Locale::Codes::Retired{'langext'}{'alpha'}{'name'} = {
};


1;
