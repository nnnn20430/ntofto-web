"""Convert docs to docsets."""


__author__ = 'Hynek Schlawack'
__version__ = '1.1.0'
__license__ = 'MIT'
