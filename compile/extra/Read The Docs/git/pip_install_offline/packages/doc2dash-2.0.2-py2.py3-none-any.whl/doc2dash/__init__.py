"""
Convert docs to Dash.app's docset format.
"""

from __future__ import absolute_import, division, print_function


__author__ = 'Hynek Schlawack'
__version__ = '2.0.2'
__license__ = 'MIT'
