from __future__ import absolute_import, division, print_function


ATTRIBUTE = u"Attribute"
CLASS = u"Class"
CONSTANT = u"Constant"
ENV = u"Environment"
EXCEPTION = u"Exception"
FUNCTION = u"Function"
INTERFACE = u"Interface"
MACRO = u"Macro"
METHOD = u"Method"
OPCODE = u"Operator"
OPTION = u"Option"
PACKAGE = u"Module"
TYPE = u"Type"
VALUE = u"Value"
VARIABLE = u"Variable"
