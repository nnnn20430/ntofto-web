====================================
 celery.worker.strategy
====================================

.. contents::
    :local:
.. currentmodule:: celery.worker.strategy

.. automodule:: celery.worker.strategy
    :members:
    :undoc-members:
