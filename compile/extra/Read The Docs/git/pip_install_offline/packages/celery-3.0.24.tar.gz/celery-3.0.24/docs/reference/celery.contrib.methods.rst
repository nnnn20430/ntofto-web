.. currentmodule:: celery.contrib.methods

.. automodule:: celery.contrib.methods
    :members:
    :undoc-members:
