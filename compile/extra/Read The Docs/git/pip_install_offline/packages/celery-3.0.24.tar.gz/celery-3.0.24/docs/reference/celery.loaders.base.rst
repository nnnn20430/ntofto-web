===========================================
 celery.loaders.base
===========================================

.. contents::
    :local:
.. currentmodule:: celery.loaders.base

.. automodule:: celery.loaders.base
    :members:
    :undoc-members:
