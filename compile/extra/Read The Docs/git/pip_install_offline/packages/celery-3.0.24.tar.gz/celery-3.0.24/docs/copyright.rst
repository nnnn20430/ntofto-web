Copyright
=========

*Celery User Manual*

by Ask Solem

.. |copy|   unicode:: U+000A9 .. COPYRIGHT SIGN

Copyright |copy| 2009-2013, Ask Solem.

All rights reserved.  This material may be copied or distributed only
subject to the terms and conditions set forth in the `Creative Commons
Attribution-Noncommercial-Share Alike 3.0 United States License
<http://creativecommons.org/licenses/by-nc-sa/3.0/us/>`_.  You must
give the original author credit.  You may not use this work for
commercial purposes.  If you alter, transform, or build upon this
work, you may distribute the resulting work only under the same or
similar license to this one.

.. note::

   While the *Celery* documentation is offered under the
   Creative Commons *attribution-nonconmmercial-share alike 3.0 united
   states* license, the Celery *software* is offered under the
   less restrictive
   `BSD License (3 Clause) <http://www.opensource.org/licenses/BSD-3-Clause>`_
