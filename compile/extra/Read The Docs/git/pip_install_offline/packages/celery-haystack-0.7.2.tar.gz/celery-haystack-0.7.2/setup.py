#!/usr/bin/env python
from setuptools import setup

setup(setup_requires=['d2to1'], d2to1=True)
