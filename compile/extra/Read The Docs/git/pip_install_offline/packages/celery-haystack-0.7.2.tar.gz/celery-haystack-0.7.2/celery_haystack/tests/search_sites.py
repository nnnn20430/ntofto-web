import haystack

haystack.autodiscover()
