API documentation
=================

.. toctree::
   :maxdepth: 2

   client
   users
   organizations
   teams
   issues
   pull_requests
   network
   repos
   commit
   object

Additionally the following documentation may be useful to :mod:`github2`
contributors:

.. toctree::
   :maxdepth: 2

   core
   request
