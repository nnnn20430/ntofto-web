License
=======

This software is licensed under the ``New BSD License``.  The full license text
follows:

.. literalinclude:: ../LICENSE
