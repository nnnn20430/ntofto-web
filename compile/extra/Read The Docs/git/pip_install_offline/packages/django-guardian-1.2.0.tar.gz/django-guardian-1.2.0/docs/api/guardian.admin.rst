.. _api-admin:

Admin
=====

.. automodule:: guardian.admin


.. admin:: GuardedModelAdmin

GuardedModelAdmin
-----------------

.. autoclass:: guardian.admin.GuardedModelAdmin
   :members:

